import pathlib,hashlib,json,csv,math,statistics as st
from collections import defaultdict
import numpy as np
from scipy.io import loadmat
root=pathlib.Path.cwd();e=root/"evidence";p=e/"Aging_Dataset_Cycling.mat"
h=hashlib.sha256()
with p.open("rb") as f:
    for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
assert h.hexdigest()=="c9048b0cf5a089e09a9e97470ca5dd4048e9eb538b5c3ff69277babc52cf2d96"
def unwrap(x):
    while isinstance(x,np.ndarray) and x.size==1 and x.dtype.kind=="O":x=x.flat[0]
    return x
def v(x,k):return np.asarray(unwrap(getattr(unwrap(x),k)),dtype=float).ravel()
d=loadmat(p,variable_names=["D"],struct_as_record=False,squeeze_me=False)["D"]
assert d.shape==(3,7)
a=unwrap(d[0,0]);ages=np.asarray(unwrap(d[0,5])).ravel()
assert a.shape==(50,5) and len(ages)==47
groups=defaultdict(list)
for j,c in enumerate(ages):
    for k in range(a.shape[1]):
        x=unwrap(a[j,k])
        if isinstance(x,np.ndarray) and x.size==0:continue
        t=v(x,"Time");t=t-t[0];i=np.abs(v(x,"I_EL"));volt=v(x,"V_batt")
        assert len(t)>1 and all(len(z)==len(t) and np.isfinite(z).all() for z in (t,i,volt)) and np.all(np.diff(t)>=0)
        q=np.r_[0.,np.cumsum(np.diff(t)*(i[:-1]+i[1:])/7200)]
        total=float(q[-1]);assert total>0
        checkpoints=[]
        # Voltage is trailing median, never using a sample after a checkpoint.
        for ts in list(range(60,int(t[-1])+1,30))+[float(t[-1])]:
            idx=int(np.searchsorted(t,ts,side="right"))-1
            lo=int(np.searchsorted(t,ts-60,side="left"))
            if idx<lo:continue
            checkpoints.append((float(ts),float(q[idx]),float(np.median(volt[lo:idx+1]))))
        r={"cycle":int(c),"repeat":k+1,"q":total,"duration":float(t[-1]),"checkpoints":checkpoints,
            "admit":not (int(c)==750 and k==0)}
        # The historical reference monotone voltage envelope is built only
        # from completed discharges, and ends at the last recorded sample.
        cpa=np.array(checkpoints)
        vv=np.minimum.accumulate(cpa[:,2])
        # Collapse ties in favor of earliest crossing; interpolation is only
        # over PAST completed trajectories.
        unique,idx=np.unique(vv,return_index=True)
        r["v_reference"]=unique
        r["f_reference"]=cpa[idx,1]/total
        groups[int(c)].append(r)
cycles=sorted(groups);assert len(cycles)==47 and sum(map(len,groups.values()))==135
def med(c):return st.median(r["q"] for r in groups[c] if r["admit"])
def score(c,q,voltage,refs):
    vals=[]
    for r in refs:
        vv=r["v_reference"];ff=r["f_reference"]
        if not vv[0]<=voltage<=vv[-1]:continue
        f=float(np.interp(voltage,vv,ff))
        if f<.15:continue
        vals.append(q/f)
    # Need evidence from at least 3 historical runs.
    return (st.median(vals),len(vals)) if len(vals)>=3 else (None,len(vals))
def selftest():
    ref={"v_reference":np.array([3.0,3.5,4.0]),"f_reference":np.array([1.0,.5,0.0])}
    q,n=score(10,10,3.5,[ref]*3);assert q==20 and n==3
    assert score(10,10,2.9,[ref]*3)[0] is None
    assert score(10,10,3.5,[ref]*2)[0] is None
selftest()
results=[];trace=[]
for j in range(15,len(cycles)):
    c=cycles[j];prev=cycles[j-1]
    refstages=cycles[j-3:j]
    refs=[r for pc in refstages for r in groups[pc] if r["admit"]]
    assert all(r["cycle"]<c for r in refs)
    baseline=med(prev)
    for r in groups[c]:
        # Fixed rule: at least 3 historical references, two consecutive
        # 60-second evaluations, predicted loss >= 1 Ah. No tuning on outcomes.
        consecutive=0;first_alarm=None;last_eval=None;nvalid=0;nc=0;min_pred=None
        for t,q,volt in r["checkpoints"]:
            if t<300 or t%60!=0 or t>=r["duration"]:continue
            pred,n=score(c,q,volt,refs)
            nc+=1
            if pred is not None:
                nvalid+=1;min_pred=pred if min_pred is None else min(pred,min_pred)
            if pred is not None and pred<=baseline-1:
                consecutive=consecutive+1 if last_eval==t-60 else 1
            else:consecutive=0
            if consecutive>=2 and first_alarm is None:first_alarm=t
            last_eval=t
            trace.append({"cycle":c,"repeat":r["repeat"],"elapsed_s":t,"partial_Ah":q,
              "trailing_voltage_V":volt,"historical_runs":n,"predicted_Ah":pred,
              "baseline_Ah":baseline,"consecutive_warning":consecutive,"alarm_active":first_alarm is not None})
        results.append({"cycle":c,"repeat":r["repeat"],"admitted":r["admit"],
          "actual_Ah":r["q"],"previous_stage_Ah":baseline,"duration_s":r["duration"],
          "event_drop_ge_1Ah":baseline-r["q"]>=1,"first_alarm_s":first_alarm,
          "lead_s":None if first_alarm is None else r["duration"]-first_alarm,
          "valid_checkpoints":nvalid,"total_checkpoints":nc,"reference_stages":refstages,
          "min_prediction_Ah":min_pred})
assert len(results)==97 and sum(x["event_drop_ge_1Ah"] for x in results)==4
def metrics(lead,records):
    out={"TP":0,"FP":0,"FN":0,"TN":0,"unscorable":0}
    for r in records:
        w=r["lead_s"] is not None and r["lead_s"]>=lead
        ev=r["event_drop_ge_1Ah"]
        out["TP" if w and ev else "FP" if w else "FN" if ev else "TN"]+=1
        if not r["valid_checkpoints"]:out["unscorable"]+=1
    return out
res={"goal":"lco-20261125-dynamic-voltage-fraction-prior-only-v1","source_sha256":h.hexdigest(),
 "physical_cells":1,"records":135,"stages":47,"training_warmup_stages":15,"tested_stages":32,
 "fixed_rule":"prior 3 stages, >=3 usable reference curves, trailing 60s median voltage, no extrapolation, f>=0.15, 2 consecutive 60s checkpoints with Q_est <= previous median -1 Ah",
 "retrospective_known_events":True,"same_stage_training":False,"physical_certified":False,"release":False,
 "metrics":{str(s):metrics(s,results) for s in (0,60,300,600)},
 "admitted_metrics":{str(s):metrics(s,[r for r in results if r["admitted"]]) for s in (0,60,300,600)},
 "events":[r for r in results if r["event_drop_ge_1Ah"]],"non_event_alarms":[r for r in results if not r["event_drop_ge_1Ah"] and r["first_alarm_s"] is not None],
 "trace_rows":len(trace)}
def writecsv(p,rows):
    with p.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
writecsv(e/"LCO_DYNAMIC_ALARMS_20261125.csv",results);writecsv(e/"LCO_DYNAMIC_TRACE_20261125.csv",trace)
(e/"LCO_DYNAMIC_RECEIPT_20261125.json").write_text(json.dumps(res,indent=2,allow_nan=False),encoding="utf-8")
print(json.dumps(res,ensure_ascii=False,separators=(",",":")))
