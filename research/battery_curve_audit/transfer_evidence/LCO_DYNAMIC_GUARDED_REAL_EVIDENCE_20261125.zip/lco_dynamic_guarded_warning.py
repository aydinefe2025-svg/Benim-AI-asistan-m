import csv,json,pathlib,math,statistics as st
from collections import defaultdict
import numpy as np
# Reuse raw-source identity and complete chronological inventory from versioned script.
# It also produces the first dynamic-rule evidence, unchanged.
from lco_dynamic_voltage_warning import groups,cycles,med,e,h
rules=("past_lower_envelope_50mV","terminal_linear_3p0V","both_agree")
rows=[];tr=[]
for j in range(15,len(cycles)):
    c=cycles[j];baseline=med(cycles[j-1])
    refs=[r for pc in cycles[j-3:j] for r in groups[pc] if r["admit"]]
    assert all(r["cycle"]<c for r in refs)
    for r in groups[c]:
        hits={k:0 for k in rules}; first={k:None for k in rules}; prev_t=None;hist={}
        for t,q,v in r["checkpoints"]:
            if t%60!=0 or t>=r["duration"]:continue
            hist[t]=(q,v)
            if t<300:continue
            vals=[]
            for ref in refs:
                a=np.asarray(ref["checkpoints"]); qq,idx=np.unique(a[:,1],return_index=True)
                if qq[0]<=q<=qq[-1]:vals.append(float(np.interp(q,qq,a[idx,2])))
            # Fixed 50 mV guard beyond the previous three-stage lower envelope.
            # Restrict to remaining charge > 1 Ah relative to previous median,
            # so an alarm cannot simply observe the normal end of a discharge.
            env=(len(vals)>=3 and q<=baseline-1 and v<min(vals)-.05)
            # Independent causal linear extrapolation to 3.0 V, with
            # 180 s slope and low-voltage gating; no end-time predictor input.
            pred=None;old=hist.get(t-180)
            if old is not None and q>old[0] and v<=3.4:
                slope=(v-old[1])/(q-old[0])
                if slope<-.01 and v>3.0:pred=q+(3.0-v)/slope
            knee=pred is not None and pred<=baseline-1
            flags=dict(zip(rules,(env,knee,env and knee)))
            for k,b in flags.items():
                hits[k]=(hits[k]+1 if prev_t==t-60 else 1) if b else 0
                if hits[k]>=2 and first[k] is None:first[k]=t
            prev_t=t
            tr.append({"cycle":c,"repeat":r["repeat"],"elapsed_s":t,"partial_Ah":q,
                "voltage":v,"ref_count":len(vals),"lower_ref_voltage":min(vals) if vals else None,
                "terminal_extrapolated_Ah":pred,**flags})
        rows.append({"cycle":c,"repeat":r["repeat"],"actual_Ah":r["q"],"duration_s":r["duration"],
            "prior_Ah":baseline,"event":baseline-r["q"]>=1,"admitted":r["admit"],
            **{k+"_lead_s":None if first[k] is None else r["duration"]-first[k] for k in rules}})
assert len(rows)==97 and sum(r["event"] for r in rows)==4
def met(k,lead):
    a=[(r["event"],r[k+"_lead_s"] is not None and r[k+"_lead_s"]>=lead) for r in rows]
    return {"TP":sum(e and w for e,w in a),"FP":sum(not e and w for e,w in a),
            "FN":sum(e and not w for e,w in a),"TN":sum(not e and not w for e,w in a)}
res={"goal":"lco-20261125-dynamic-envelope-knee-guard-v1","source_sha256":h.hexdigest(),
    "n":len(rows),"fixed_exploratory_rules":True,"known_outcomes":True,
    "same_stage_training":False,"rules":{k:{str(s):met(k,s) for s in (0,60,300,600)} for k in rules},
    "events":[r for r in rows if r["event"]],"trace_rows":len(tr),
    "independent_physical_validation":False,"production_release":False}
for name,data in (("LCO_GUARDED_DYNAMIC_ALARMS_20261125.csv",rows),("LCO_GUARDED_DYNAMIC_TRACE_20261125.csv",tr)):
    with (e/name).open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(e/"LCO_GUARDED_DYNAMIC_RECEIPT_20261125.json").write_text(json.dumps(res,indent=2),encoding="utf-8")
print("GUARDED_RESULT",json.dumps(res,separators=(",",":")),flush=True)
