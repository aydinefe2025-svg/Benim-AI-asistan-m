import csv,json,hashlib,pathlib,statistics as st,zipfile,math
from collections import defaultdict
root=pathlib.Path.cwd(); e=root/"evidence"
records=list(csv.DictReader((e/"LCO_GUARDED_DYNAMIC_ALARMS_20261125.csv").open(encoding="utf-8")))
trace=list(csv.DictReader((e/"LCO_GUARDED_DYNAMIC_TRACE_20261125.csv").open(encoding="utf-8")))
ref=json.loads((e/"LCO_GUARDED_DYNAMIC_RECEIPT_20261125.json").read_text(encoding="utf-8"))
assert len(records)==97 and len(trace)==4841
key=lambda r:(int(r["cycle"]),int(r["repeat"]))
g=defaultdict(list)
for x in trace:g[key(x)].append(x)
assert len(g)==97 and len({key(x) for x in records})==97
rules=list(ref["rules"]); checks=0;slope_checks=0
for r in records:
    a=g[key(r)]; t0=None;cnt=dict.fromkeys(rules,0);first=dict.fromkeys(rules,None);baseline=float(r["prior_Ah"])
    hist={}
    for x in a:
        t=float(x["elapsed_s"]);q=float(x["partial_Ah"]);v=float(x["voltage"]); n=int(x["ref_count"])
        assert t<float(r["duration_s"]) and (t0 is None or t>t0)
        env=n>=3 and q<=baseline-1 and bool(x["lower_ref_voltage"]) and v<float(x["lower_ref_voltage"])-.05
        pr=float(x["terminal_extrapolated_Ah"]) if x["terminal_extrapolated_Ah"] else None
        knee=pr is not None and pr<=baseline-1
        assert (env,knee,env and knee)==tuple(x[k]=="True" for k in rules)
        if t-180 in hist:
            q0,v0=hist[t-180];p=None
            if q>q0 and v<=3.4:
                m=(v-v0)/(q-q0)
                if m<-.01 and v>3:p=q+(3-v)/m
            assert (p is None)==(pr is None)
            if p is not None:assert math.isclose(p,pr,abs_tol=1e-10,rel_tol=1e-12)
            slope_checks+=1
        hist[t]=(q,v)
        for k,flag in zip(rules,(env,knee,env and knee)):
            cnt[k]=(cnt[k]+1 if t0==t-60 else 1) if flag else 0
            if cnt[k]>=2 and first[k] is None:first[k]=t
        t0=t;checks+=1
    for k in rules:
        x=r[k+"_lead_s"];expected=None if first[k] is None else float(r["duration_s"])-first[k]
        assert (not x)==(expected is None)
        if x:assert math.isclose(float(x),expected,abs_tol=1e-10)
for k in rules:
    for lead,m in ref["rules"][k].items():
        rows=[(float(r["prior_Ah"])-float(r["actual_Ah"])>=1,bool(r[k+"_lead_s"]) and float(r[k+"_lead_s"])>=float(lead)) for r in records]
        assert m=={"TP":sum(a and b for a,b in rows),"FP":sum(not a and b for a,b in rows),"FN":sum(a and not b for a,b in rows),"TN":sum(not a and not b for a,b in rows)}
assert checks==4841
out={"goal":ref["goal"],"source_sha256":ref["source_sha256"],"record_count":len(records),"trace_decisions_recomputed":checks,"terminal_slope_recomputations":slope_checks,"alarm_lead_checks":len(records)*len(rules),"metric_tables":12,"all_pass":True,"scope":"independent decision and arithmetic verification from derived trace, not independent physical experiment"}
(e/"LCO_DYNAMIC_INDEPENDENT_CHECK_20261125.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
names=["lco_dynamic_voltage_warning.py","lco_dynamic_guarded_warning.py","lco_dynamic_verify.py",
"evidence/LCO_DYNAMIC_ALARMS_20261125.csv","evidence/LCO_DYNAMIC_TRACE_20261125.csv","evidence/LCO_DYNAMIC_RECEIPT_20261125.json","evidence/LCO_GUARDED_DYNAMIC_ALARMS_20261125.csv","evidence/LCO_GUARDED_DYNAMIC_TRACE_20261125.csv","evidence/LCO_GUARDED_DYNAMIC_RECEIPT_20261125.json","evidence/LCO_DYNAMIC_INDEPENDENT_CHECK_20261125.json"]
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names}
p=root/"LCO_DYNAMIC_GUARDED_REAL_EVIDENCE_20261125.zip"
with zipfile.ZipFile(p,"x",zipfile.ZIP_DEFLATED) as z:
    for n in names:z.write(root/n,n)
    z.writestr("SHA256_MANIFEST.json",json.dumps(manifest,indent=2))
with zipfile.ZipFile(p) as z:
    assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==s for n,s in manifest.items())
print(json.dumps({"verify":out,"file":p.name,"size":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"members":len(names)},separators=(",",":")))
