import csv,json,math,statistics as st,pathlib,hashlib
from collections import defaultdict
e=pathlib.Path.cwd()/"evidence"
src=e/"LCO_PREFIX_PREDICTIONS_20261125.csv"
rows=[]
for r in csv.DictReader(src.open(encoding="utf-8")):
    rows.append({k:int(v) if k in ("cutoff_s","cycle","repeat") else v=="True" if k in ("admitted","event_drop_ge_1Ah") else float(v) for k,v in r.items()})
assert len(rows)==291
out=[]
for cut in (300,600):
    rr=[r for r in rows if r["cutoff_s"]==cut];g=defaultdict(list)
    for r in rr:g[r["cycle"]].append(r)
    for model in ("electrical_prefix","electrical_mechanical_prefix"):
        for include_short in (True,False):
            for alpha in (.10,.05):
                past=[]
                for c,rs in sorted(g.items()):
                    # Each cycle contributes at most one calibration score; no same-cycle labels.
                    rank=math.ceil((len(past)+1)*(1-alpha)-1e-12)
                    b=sorted(past)[rank-1] if 1<=rank<=len(past) else None
                    for r in rs:
                        lo=r[model]-b if b is not None else None
                        out.append({"cutoff_s":cut,"model":model,"include_prior_short":include_short,
                         "alpha":alpha,"cycle":c,"repeat":r["repeat"],"n_prior_stages":len(past),
                         "margin_Ah":b,"lower_Ah":lo,"actual_Ah":r["actual_Ah"],"event":r["event_drop_ge_1Ah"],
                         "warning":None if lo is None else lo<=r["previous_stage_Ah"]-1})
                    vals=[max(0,r[model]-r["actual_Ah"]) for r in rs if include_short or r["admitted"]]
                    if vals:past.append(max(vals))
summary=[]
for cut in (300,600):
    for model in ("electrical_prefix","electrical_mechanical_prefix"):
        for short in (True,False):
            for alpha in (.10,.05):
                r=[x for x in out if (x["cutoff_s"],x["model"],x["include_prior_short"],x["alpha"])==(cut,model,short,alpha)]
                s=[x for x in r if x["warning"] is not None]
                summary.append({"cutoff_s":cut,"model":model,"include_prior_short":short,"alpha":alpha,
                    "scored":len(s),"abstained":len(r)-len(s),"events_abstained":sum(x["event"] for x in r if x["warning"] is None),
                    "TP":sum(x["warning"] and x["event"] for x in s),"FP":sum(x["warning"] and not x["event"] for x in s),
                    "FN":sum(not x["warning"] and x["event"] for x in s),"TN":sum(not x["warning"] and not x["event"] for x in s),
                    "lower_bound_violations":sum(x["actual_Ah"]<x["lower_Ah"] for x in s),
                    "last_stage":[{k:x[k] for k in ("repeat","margin_Ah","lower_Ah","actual_Ah","warning")} for x in s if x["cycle"]==1125]})
receipt={"goal":"lco-20261125-past-only-risk-band","source_prediction_sha256":hashlib.sha256(src.read_bytes()).hexdigest(),
 "grouped_prior_only_calibration":True,"exchangeability_not_established":True,"guaranteed_coverage":False,
 "known_retrospective_event":True,"summary":summary,"physical_safety_release":False}
(e/"LCO_PREFIX_RISK_BAND_20261125.json").write_text(json.dumps(receipt,indent=2,allow_nan=False),encoding="utf-8")
with (e/"LCO_PREFIX_RISK_DECISIONS_20261125.csv").open("w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print("RISK",json.dumps(summary,separators=(",",":")))
print("HASHES",json.dumps({n:hashlib.sha256((e/n).read_bytes()).hexdigest() for n in ("LCO_PREFIX_EARLY_WARNING_20261125.json","LCO_PREFIX_PREDICTIONS_20261125.csv","LCO_PREFIX_RISK_BAND_20261125.json","LCO_PREFIX_RISK_DECISIONS_20261125.csv")}))
