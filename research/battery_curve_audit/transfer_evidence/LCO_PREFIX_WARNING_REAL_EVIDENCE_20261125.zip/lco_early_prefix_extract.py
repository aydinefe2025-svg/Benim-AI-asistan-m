import pathlib,hashlib,json,csv,io,gzip,base64,math
import numpy as np
from scipy.io import loadmat
e=pathlib.Path.cwd()/"evidence"
p=e/"Aging_Dataset_Cycling.mat"
h=hashlib.sha256()
with p.open("rb") as f:
    for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
assert h.hexdigest()=="c9048b0cf5a089e09a9e97470ca5dd4048e9eb538b5c3ff69277babc52cf2d96"
d=loadmat(p,variable_names=["D"],struct_as_record=False,squeeze_me=False)["D"]
assert d.shape==(3,7)
def unwrap(x):
    while isinstance(x,np.ndarray) and x.size==1 and x.dtype.kind=="O":x=x.flat[0]
    return x
def v(x,k):return np.asarray(unwrap(getattr(unwrap(x),k)),dtype=float).ravel()
a=unwrap(d[0,0]);ages=np.asarray(unwrap(d[0,5])).ravel()
assert a.shape==(50,5) and len(ages)==47
rows=[]
for j,c in enumerate(ages):
    for k in range(a.shape[1]):
        x=unwrap(a[j,k])
        if isinstance(x,np.ndarray) and x.size==0:continue
        t=v(x,"Time"); t=t-t[0]; i=v(x,"I_EL"); volt=v(x,"V_batt"); laser=v(x,"Las1")+v(x,"Las2"); temp=v(x,"T_batt")
        assert len(t)>1 and all(len(q)==len(t) and np.isfinite(q).all() for q in (t,i,volt,laser,temp)) and np.all(np.diff(t)>=0)
        r={"cycle":int(c),"repeat":k+1,"samples":len(t),"duration_s":float(t[-1]),"q_Ah":float(np.trapezoid(np.abs(i),t)/3600)}
        for cutoff in (60,300,600):
            # No interpolation using a point after the cutoff.
            idx=np.flatnonzero(t<=cutoff); assert len(idx)>1 and t[-1]>=cutoff
            tail=idx[t[idx]>=cutoff-10]
            assert len(tail)>0
            r[f"v{cutoff}"]=float(np.median(volt[tail]));r[f"dv{cutoff}"]=float(np.median(volt[tail])-volt[0])
            r[f"dl{cutoff}"]=float(laser[0]-np.median(laser[tail]));r[f"dt{cutoff}"]=float(np.median(temp[tail])-temp[0])
        rows.append(r)
assert len(rows)==135
out=e/"early_prefix_features_20261125.csv"
with out.open("w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
b=out.read_bytes(); print("ROWS",len(rows),"SHA256",hashlib.sha256(b).hexdigest(),"BYTES",len(b))
# A compact transport table with decimal precision retained; store full values on host.
print("FIRST_LAST",rows[0],rows[-1])
