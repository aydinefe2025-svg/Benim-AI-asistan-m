import csv,json,pathlib,math,statistics as st,hashlib,base64,gzip,io
from collections import defaultdict
import numpy as np
e=pathlib.Path.cwd()/"evidence"
p=e/"early_prefix_features_20261125.csv"
assert hashlib.sha256(p.read_bytes()).hexdigest()=="5535529b29f22355f99872c8c2743bec27752049844b11695bdbbf3a8b379822"
rows=[]
for r in csv.DictReader(p.open(encoding="utf-8")):
    rows.append({k:int(v) if k in ("cycle","repeat","samples") else float(v) for k,v in r.items()})
groups=defaultdict(list)
for r in rows:groups[r["cycle"]].append(r)
cycles=sorted(groups);assert len(cycles)==47 and len(rows)==135
def admitted(r):return not (r["cycle"]==750 and r["repeat"]==1)
def base(c):return st.median(r["q_Ah"] for r in groups[c] if admitted(r))
prev={c:cycles[j-1] for j,c in enumerate(cycles) if j}
def feat(r,cut,mech):
    c=r["cycle"];pc=prev[c]
    x=[base(pc),pc,c-pc,r[f"v{cut}"],r[f"dv{cut}"],r[f"dt{cut}"]]
    if mech:x.append(r[f"dl{cut}"])
    return x
def ridge(train,r,cut,mech):
    X=np.array([feat(x,cut,mech) for x in train]); y=np.array([x["q_Ah"] for x in train]); f=np.array(feat(r,cut,mech))
    m=X.mean(0);sd=X.std(0);sd=np.where(sd>1e-12,sd,1)
    X=(X-m)/sd; f=(f-m)/sd; yc=y-y.mean()
    b=np.linalg.solve(X.T@X+np.eye(X.shape[1]),X.T@yc)
    b2=np.linalg.lstsq(np.vstack([X,np.eye(X.shape[1])]),np.r_[yc,np.zeros(X.shape[1])],rcond=None)[0]
    pred=float(y.mean()+f@b);assert abs(pred-float(y.mean()+f@b2))<1e-9
    modified=dict(r);modified.update(q_Ah=999,duration_s=999,samples=999)
    assert feat(r,cut,mech)==feat(modified,cut,mech)
    return pred
preds=[]
for cut in (60,300,600):
    for j in range(15,len(cycles)):
        c=cycles[j]; train=[r for pc in cycles[1:j] for r in groups[pc] if admitted(r)]
        assert all(x["cycle"]<c for x in train)
        for r in groups[c]:
            pc=prev[c];p0=base(pc); actual=r["q_Ah"]
            preds.append({"cutoff_s":cut,"cycle":c,"repeat":r["repeat"],"admitted":admitted(r),"actual_Ah":actual,"previous_stage_Ah":p0,
            "persistence":p0,"electrical_prefix":ridge(train,r,cut,False),"electrical_mechanical_prefix":ridge(train,r,cut,True),
            "event_drop_ge_1Ah":p0-actual>=1,"lead_s":r["duration_s"]-cut})
def summarize(rs):
    out={}
    for k in ("persistence","electrical_prefix","electrical_mechanical_prefix"):
        errs=[r[k]-r["actual_Ah"] for r in rs];event=[r["event_drop_ge_1Ah"] for r in rs]
        alarms=[r["previous_stage_Ah"]-r[k]>=1 for r in rs]
        out[k]={"MAE_Ah":st.mean(map(abs,errs)),"RMSE_Ah":math.sqrt(st.mean(v*v for v in errs)),
        "TP":sum(a and b for a,b in zip(alarms,event)),"FP":sum(a and not b for a,b in zip(alarms,event)),
        "FN":sum(not a and b for a,b in zip(alarms,event)),"TN":sum(not a and not b for a,b in zip(alarms,event))}
    return out
summary={}
for cut in (60,300,600):
    rs=[r for r in preds if r["cutoff_s"]==cut];good=[r for r in rs if r["admitted"]]
    summary[str(cut)]={"all_test_runs":len(rs),"admitted_test_runs":len(good),"all":summarize(rs),"admitted":summarize(good),"last_stage": [r for r in rs if r["cycle"]==1125],"short_challenge":[r for r in rs if not r["admitted"]]}
# No claim of true SOH. Endpoint decomposition is exact for stage means of per-run factors,
# with a duration-weighted current from summed recorded integrals and durations.
d={}
for c in (1100,1125):
    g=groups[c];q=st.mean(r["q_Ah"] for r in g);t=st.mean(r["duration_s"] for r in g);d[str(c)]={"n":len(g),"mean_q":q,"mean_duration_s":t,"effective_I_A":3600*q/t,"q_min":min(r["q_Ah"] for r in g),"q_max":max(r["q_Ah"] for r in g)}
a,b=d["1100"],d["1125"];time_effect=(b["mean_duration_s"]-a["mean_duration_s"])*a["effective_I_A"]/3600
current_effect=b["mean_duration_s"]*(b["effective_I_A"]-a["effective_I_A"])/3600
assert abs(time_effect+current_effect-(b["mean_q"]-a["mean_q"]))<1e-10
receipt={"goal":"lco-20261125-within-discharge-prefix-early-warning-v1","source_sha256":"c9048b0cf5a089e09a9e97470ca5dd4048e9eb538b5c3ff69277babc52cf2d96","features_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"physical_cells":1,"runs":len(rows),"stage_count":len(cycles),"fixed_train_stages":15,"main_cutoff_s":300,"event_threshold_Ah":1,"retrospective_known_final_event":True,"not_blind_prospective":True,"same_stage_training":False,"same_time_full_run_leakage_check":True,"independent_ridge_solution_agrees":True,"summary":summary,"last_stage_decomposition":d,"duration_effect_Ah":time_effect,"current_effect_Ah":current_effect,"physical_certification":False,"production_release":False}
o=e/"LCO_PREFIX_EARLY_WARNING_20261125.json";o.write_text(json.dumps(receipt,indent=2,allow_nan=False),encoding="utf-8")
with (e/"LCO_PREFIX_PREDICTIONS_20261125.csv").open("w",newline="",encoding="utf-8") as f:
    w=csv.DictWriter(f,fieldnames=list(preds[0]));w.writeheader();w.writerows(preds)
# Small exact 300s transport for independent local validation; 9 decimal precision.
s=io.StringIO(newline="");w=csv.writer(s,lineterminator="\n");keys=["cycle","repeat","duration_s","q_Ah","v300","dv300","dt300","dl300"];w.writerow(keys)
for r in rows:w.writerow([r[k] if k in ("cycle","repeat") else f"{r[k]:.9f}" for k in keys])
bb=s.getvalue().encode();(e/"LCO_300S_REPLAY_INPUT_20261125.csv").write_bytes(bb)
print("SUMMARY",json.dumps(receipt,separators=(",",":")),flush=True)
print("TRANSPORT",hashlib.sha256(bb).hexdigest(),len(bb),base64.b64encode(gzip.compress(bb,mtime=0)).decode(),flush=True)
